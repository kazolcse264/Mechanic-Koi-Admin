import 'package:flutter/material.dart';
import 'package:mechanic_koi_admin/models/employee_model.dart';

import '../auth/auth_service.dart';
import '../db/db_helper.dart';

class EmployeeProvider extends ChangeNotifier {
  EmployeeModel? employeeModel;
  List<EmployeeModel> employeeModelList = [];
  Future<void> addEmployee(EmployeeModel employeeModel) => DbHelper.addEmployee(employeeModel);

  Future<bool> doesUserExist(String uid) => DbHelper.doesUserExist(uid);

  getUserInfo() {
    DbHelper.getUserInfo(AuthService.currentUser!.uid).listen((snapshot) {
      if (snapshot.exists) {
        employeeModel = EmployeeModel.fromMap(snapshot.data()!);
        notifyListeners();
      }
    });
  }

  getAllEmployees() {
    DbHelper.getAllEmployees().listen((snapshot) {
      employeeModelList = List.generate(snapshot.docs.length,
              (index) => EmployeeModel.fromMap(snapshot.docs[index].data()));
      notifyListeners();
    });
  }


  Future<void> updateUserProfileField(String field, dynamic value) =>
      DbHelper.updateEmployeeProfileField(
        AuthService.currentUser!.uid,
        {field : value},
      );

}