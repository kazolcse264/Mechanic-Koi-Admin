import 'package:flutter/material.dart';
import 'package:mechanic_koi_admin/pages/add_employee_page.dart';

class EmployeeListPage extends StatefulWidget {
  static const String routeName = '/employee_list';
  const EmployeeListPage({Key? key}) : super(key: key);

  @override
  State<EmployeeListPage> createState() => _EmployeeListPageState();
}

class _EmployeeListPageState extends State<EmployeeListPage> {
  dynamic isCard = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Employee list Page'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
              'Garage Employee',
              style: TextStyle(
                fontSize: 25,
                color: Colors.black,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: OutlinedButton.icon(
              onPressed: () async{
                //for return a value from pop method
                dynamic value = await Navigator.pushNamed(context, AddEmployeePage.routeName);
                setState(() {
                  isCard = value;
                });
              },
              icon: const Icon(Icons.add_circle),
              label: const Text(
                'New Employee',
                style: TextStyle(
                  fontSize: 18,
                ),
              ),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.deepPurple,
                backgroundColor: Colors.white,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10))),
              ),
            ),
          ),
          (!isCard)? Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Employee not available.',
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.green,
                ),
              ),
              TextButton(
                onPressed: () async{
                  //for return a value from pop method
                  dynamic value = await Navigator.pushNamed(context, AddEmployeePage.routeName);
                  setState(() {
                    isCard = value;
                  });
                },
                child: const Text('Add New Employee ',style: TextStyle(
                  fontSize: 18,
                  color: Colors.deepPurple,
                ),),
              ),
            ],
          ) :Padding(
            padding: const EdgeInsets.all(8.0),
            child: Card(
              child: ListTile(
                leading:  CircleAvatar(
                  backgroundColor: Colors.white,
                  radius: 60,
                  child: Image.asset(
                    'assets/images/profile.png',
                    height: 50,
                    width:50,
                  ),
                ),
                tileColor: Colors.tealAccent.shade100,
                title: const Text('Employee Name'),
                subtitle: const Text('Email'),
                trailing: IconButton(
                  onPressed: (){

                  },
                  icon: const Icon(Icons.more_horiz),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
