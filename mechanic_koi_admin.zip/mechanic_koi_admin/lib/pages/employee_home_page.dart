import 'package:flutter/material.dart';
import 'package:mechanic_koi_admin/pages/profile_page.dart';
import 'package:mechanic_koi_admin/providers/employee_provider.dart';
import 'package:provider/provider.dart';
import '../custom_widgets/main_drawer.dart';
import '../utils/constants.dart';
import 'bottom_nav_bar_wrapper_page.dart';

class EmployeeHomePage extends StatefulWidget {
  static const String routeName = '/emp_home_page';
  const EmployeeHomePage({Key? key}) : super(key: key);

  @override
  State<EmployeeHomePage> createState() => _EmployeeHomePageState();
}

class _EmployeeHomePageState extends State<EmployeeHomePage> {
  @override
  void didChangeDependencies() {
    Provider.of<EmployeeProvider>(context,listen: false).getUserInfo();
    super.didChangeDependencies();
  }
  @override
  Widget build(BuildContext context) {
    final employeeProvider = Provider.of<EmployeeProvider>(context);

    final size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      drawer:  MainDrawer(isAdminMainDrawer: false,employeeProvider : employeeProvider),
      appBar: AppBar(
        centerTitle: true,
        elevation: 0,
        backgroundColor: const Color(0xFF2B2B2B),
        /*leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () {

          },
        ),*/
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Icon(Icons.miscellaneous_services_rounded),
            Text('SERVICE')
          ],
        ),
        actions: [
          InkWell(
            onTap: (){

              Navigator.pushReplacementNamed(context, BottomNavBarPageWrapper.routeName);
            },
            child: const Icon(Icons.notifications),
          ),
          InkWell(
            onTap: (){

              Navigator.pushNamed(context, ProfilePage.routeName, arguments: false);
            },
            child: Padding(
              padding: const EdgeInsets.only(right: 18.0, left: 8.0),
              child: CircleAvatar(
                backgroundColor: Colors.white,
                child: Image.asset('assets/images/profile.png'),
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(bottom: 50),
              // It will cover 20% of our total height
              height: size.height * 0.2,
              child: Stack(
                children: <Widget>[
                  Container(
                    padding: const EdgeInsets.only(
                      left: 20,
                      right: 20,
                      bottom: 56,
                    ),
                    height: size.height * 0.2 - 75,
                    decoration: const BoxDecoration(
                      color: Color(0xFF2B2B2B),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(36),
                        bottomRight: Radius.circular(36),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    top: 0,
                    child: Container(
                      alignment: Alignment.center,
                      margin: const EdgeInsets.symmetric(horizontal: 20),
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      height: 54,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            offset: const Offset(0, 10),
                            blurRadius: 50,
                            color: const Color(0xFF2B2B2B).withOpacity(0.23),
                          ),
                        ],
                      ),
                      child: Image.asset(
                        'assets/images/profile.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        elevation: 5,
                        shadowColor: const Color(0xFF2B2B2B),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 18.0,vertical: 28.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              Text(
                                'Total Service',
                                style: TextStyle(fontSize: 20,color: Colors.grey,),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Text(
                                '10',
                                style: TextStyle(fontSize: 20),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        elevation: 5,
                        shadowColor: const Color(0xFF2B2B2B),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 18.0,vertical: 28.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              Text(
                                'Today Service',
                                style: TextStyle(fontSize: 20,color: Colors.grey,),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Text(
                                '3',
                                style: TextStyle(fontSize: 20),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Expanded(
                      child: Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        elevation: 5,
                        shadowColor: const Color(0xFF2B2B2B),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 18.0,vertical: 28.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Attendance',
                                style: TextStyle(fontSize: 20,color: Colors.grey),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Row(
                                //mainAxisSize: MainAxisSize.min,
                                //mainAxisAlignment: MainAxisAlignment.center,
                                children: const [
                                  Icon(Icons.people),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    '30',
                                    style: TextStyle(fontSize: 20),
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        elevation: 5,
                        shadowColor: const Color(0xFF2B2B2B),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 18.0,vertical: 28.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Salary',
                                style: TextStyle(fontSize: 20,color: Colors.grey),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Row(
                                //mainAxisSize: MainAxisSize.min,
                                //mainAxisAlignment: MainAxisAlignment.center,
                                children: const [
                                  Icon(Icons.card_giftcard),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    '$currencySymbol 10,000.00',
                                    style: TextStyle(fontSize: 20),
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
