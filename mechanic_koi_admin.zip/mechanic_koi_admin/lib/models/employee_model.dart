import 'package:cloud_firestore/cloud_firestore.dart';

import 'address_model.dart';

const String collectionEmployees = 'Employees';

const String employeeFieldEmployeeId = 'employeeId';
const String employeeFieldDisplayName = 'displayName';
const String employeeFieldEmployeeImageUrl = 'employeeImageUrl';
const String employeeFieldGender = 'gender';
const String employeeFieldPhone = 'phone';
const String employeeFieldEmail = 'email';
const String employeeFieldAge = 'age';
const String employeeFieldSalary = 'salary';
const String employeeFieldEmployeeCreationTime = 'employeeCreationTime';
const String employeeFieldAddressModel = 'addressModel';

class EmployeeModel {
  String? employeeId;
  String? displayName;
  String? employeeImageUrl;
  String? gender;
  String? phone;
  String email;
  num? age;
  num? salary;
  Timestamp? employeeCreationTime;
  AddressModel? addressModel;


  EmployeeModel({
    this.employeeId,
    this.displayName,
    this.employeeImageUrl,
    this.gender,
    this.phone,
    required this.email,
    this.age,
    this.salary,
    this.employeeCreationTime,
    this.addressModel,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      employeeFieldEmployeeId: employeeId,
      employeeFieldDisplayName: displayName,
      employeeFieldEmployeeImageUrl: employeeImageUrl,
      employeeFieldGender: gender,
      employeeFieldPhone: phone,
      employeeFieldEmail: email,
      employeeFieldAge: age,
      employeeFieldSalary: salary,
      employeeFieldEmployeeCreationTime: employeeCreationTime,
      employeeFieldAddressModel: addressModel?.toMap(),
    };
  }

  factory EmployeeModel.fromMap(Map<String, dynamic> map) => EmployeeModel(
    employeeId: map[employeeFieldEmployeeId],
    displayName: map[employeeFieldDisplayName],
    employeeImageUrl: map[employeeFieldEmployeeImageUrl],
    gender: map[employeeFieldGender],
    phone: map[employeeFieldPhone],
    email: map[employeeFieldEmail],
    age: map[employeeFieldAge],
    salary: map[employeeFieldSalary],
    employeeCreationTime: map[employeeFieldEmployeeCreationTime],
    addressModel: map[employeeFieldAddressModel] == null ? null : AddressModel.fromMap(map[employeeFieldAddressModel]),
  );
}
