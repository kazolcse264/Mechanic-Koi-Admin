package com.example.mechanic_koi_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
